/**
 * app.js - Lógica SPA, Búsqueda, Filtros y Datos de Prueba para DonaJusto
 * Proyecto EFI de Programación II 2026
 * 
 * Reglas seguidas:
 * - ADR-001 / ADR-002: SPA client-side sin recargas de página.
 * - ADR-003: Modal interactivo para detalle de comedores.
 * - ADR-004: Datos 100% ficticios en memoria local, sin llamadas fetch() a JSON.
 * - EC-001: Modo oscuro mediante clase 'dark' en el elemento html con SVG icons.
 * - EC-006: Barras de nivel de stock con <progress> sin estilos inline.
 * - EC-007: Bloqueo de scroll en body al abrir modal y cierre de menú móvil al navegar.
 */

// ==========================================================================
// 1. ICONOS VECTORIALES SVG REUTILIZABLES
// ==========================================================================

const SVG_ICONS = {
    sun: `<svg class="w-5 h-5 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>`,
    moon: `<svg class="w-5 h-5 text-slate-600 dark:text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>`,
    location: `<svg class="w-3.5 h-3.5 text-slate-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>`,
    users: `<svg class="w-3.5 h-3.5 text-slate-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>`,
    clock: `<svg class="w-3.5 h-3.5 text-slate-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`,
    package: `<svg class="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>`,
    alert: `<svg class="w-3.5 h-3.5 text-amber-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>`,
    alertRed: `<svg class="w-3.5 h-3.5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>`,
    arrowRight: `<svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>`,
    search: `<svg class="w-8 h-8 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>`,
    categoryMilk: `<svg class="w-4 h-4 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>`,
    categoryGrain: `<svg class="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3v18m0-18l4 4m-4-4L8 7m4 5l4 4m-4-4l-4 4m4 5l4-4m-4 4l-4-4"/></svg>`,
    categoryOil: `<svg class="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"/></svg>`
};

// ==========================================================================
// 1.1 BANNERS ILUSTRADOS VECTORIALES POR COMEDOR (100% OFFLINE Y NATIVOS)
// ==========================================================================

const COMEDOR_BANNERS = {
    'rincon-de-luz': `
        <svg viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="bg-rdl" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#ea580c"/>
                    <stop offset="100%" stop-color="#f59e0b"/>
                </linearGradient>
            </defs>
            <rect width="400" height="140" fill="url(#bg-rdl)"/>
            <circle cx="340" cy="70" r="90" fill="#ffffff" fill-opacity="0.12"/>
            <circle cx="60" cy="110" r="60" fill="#000000" fill-opacity="0.08"/>
            <g transform="translate(160, 20)">
                <path d="M28 8 Q32 0 36 8 T44 8" stroke="#ffffff" stroke-width="2.5" fill="none" stroke-linecap="round" opacity="0.8"/>
                <path d="M42 5 Q46 -3 50 5 T58 5" stroke="#ffffff" stroke-width="2.5" fill="none" stroke-linecap="round" opacity="0.9"/>
                <path d="M56 8 Q60 0 64 8 T72 8" stroke="#ffffff" stroke-width="2.5" fill="none" stroke-linecap="round" opacity="0.8"/>
                <path d="M15 32 C15 62 25 76 50 76 C75 76 85 62 85 32 Z" fill="#ffffff" fill-opacity="0.95"/>
                <path d="M8 38 C4 38 4 48 8 48" stroke="#ffffff" stroke-width="3" fill="none" stroke-linecap="round"/>
                <path d="M92 38 C96 38 96 48 92 48" stroke="#ffffff" stroke-width="3" fill="none" stroke-linecap="round"/>
                <rect x="12" y="28" width="76" height="6" rx="3" fill="#fed7aa"/>
                <path d="M50 44 C48 40 42 40 42 45 C42 50 50 55 50 55 C50 55 58 50 58 45 C58 40 52 40 50 44 Z" fill="#ea580c"/>
            </g>
        </svg>
    `,
    'sonrisas-del-manana': `
        <svg viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="bg-sdm" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#d97706"/>
                    <stop offset="100%" stop-color="#fbbf24"/>
                </linearGradient>
            </defs>
            <rect width="400" height="140" fill="url(#bg-sdm)"/>
            <circle cx="80" cy="50" r="70" fill="#ffffff" fill-opacity="0.15"/>
            <circle cx="320" cy="100" r="80" fill="#ffffff" fill-opacity="0.1"/>
            <g transform="translate(160, 22)">
                <circle cx="45" cy="50" r="42" fill="#fef3c7" fill-opacity="0.3"/>
                <path d="M22 30 L26 68 C27 75 35 78 45 78 C55 78 63 75 64 68 L68 30 Z" fill="#ffffff" fill-opacity="0.95"/>
                <path d="M66 36 C76 36 76 54 64 58" stroke="#ffffff" stroke-width="4" fill="none" stroke-linecap="round"/>
                <circle cx="38" cy="48" r="2.5" fill="#d97706"/>
                <circle cx="52" cy="48" r="2.5" fill="#d97706"/>
                <path d="M40 56 Q45 61 50 56" stroke="#d97706" stroke-width="2" fill="none" stroke-linecap="round"/>
                <path d="M38 18 Q41 10 44 18" stroke="#ffffff" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                <path d="M48 16 Q51 8 54 16" stroke="#ffffff" stroke-width="2.5" fill="none" stroke-linecap="round"/>
            </g>
        </svg>
    `,
    'manos-unidas': `
        <svg viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="bg-mu" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#047857"/>
                    <stop offset="100%" stop-color="#10b981"/>
                </linearGradient>
            </defs>
            <rect width="400" height="140" fill="url(#bg-mu)"/>
            <circle cx="330" cy="50" r="75" fill="#ffffff" fill-opacity="0.12"/>
            <circle cx="70" cy="110" r="65" fill="#064e3b" fill-opacity="0.2"/>
            <g transform="translate(155, 18)">
                <path d="M15 36 L22 74 C23 78 30 80 50 80 C70 80 77 78 78 74 L85 36 Z" fill="#ffffff" fill-opacity="0.95"/>
                <path d="M22 36 C22 10 78 10 78 36" stroke="#ffffff" stroke-width="3.5" fill="none"/>
                <circle cx="38" cy="32" r="10" fill="#ef4444"/>
                <polygon points="56,36 68,18 72,24" fill="#f97316"/>
                <path d="M45 28 Q48 16 52 24" stroke="#10b981" stroke-width="3" fill="none"/>
                <path d="M50 50 C48 46 43 46 43 51 C43 55 50 60 50 60 C50 60 57 55 57 51 C57 46 52 46 50 50 Z" fill="#059669"/>
            </g>
        </svg>
    `,
    'panza-llena': `
        <svg viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="bg-pl" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#15803d"/>
                    <stop offset="100%" stop-color="#65a30d"/>
                </linearGradient>
            </defs>
            <rect width="400" height="140" fill="url(#bg-pl)"/>
            <circle cx="80" cy="40" r="70" fill="#ffffff" fill-opacity="0.12"/>
            <circle cx="340" cy="110" r="80" fill="#ffffff" fill-opacity="0.1"/>
            <g transform="translate(160, 20)">
                <path d="M5 75 Q45 68 85 75" stroke="#ffffff" stroke-width="3" stroke-linecap="round" fill="none"/>
                <path d="M45 72 C45 45 45 35 45 25" stroke="#ffffff" stroke-width="3.5" stroke-linecap="round"/>
                <path d="M45 42 C30 35 25 48 45 46" fill="#d9f99d"/>
                <path d="M45 34 C60 27 65 40 45 38" fill="#a3e635"/>
                <ellipse cx="65" cy="62" rx="14" ry="11" fill="#f59e0b"/>
                <path d="M65 51 L66 47" stroke="#15803d" stroke-width="2.5" stroke-linecap="round"/>
                <path d="M15 58 C15 70 35 70 35 58 Z" fill="#ffffff" fill-opacity="0.9"/>
            </g>
        </svg>
    `,
    'el-buen-sembrador': `
        <svg viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="bg-ebs" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#0f766e"/>
                    <stop offset="100%" stop-color="#14b8a6"/>
                </linearGradient>
            </defs>
            <rect width="400" height="140" fill="url(#bg-ebs)"/>
            <circle cx="320" cy="45" r="70" fill="#ffffff" fill-opacity="0.14"/>
            <circle cx="60" cy="100" r="60" fill="#042f2e" fill-opacity="0.15"/>
            <g transform="translate(155, 22)">
                <path d="M15 65 Q45 60 48 74 Q51 60 81 65 L81 48 Q51 43 48 56 Q45 43 15 48 Z" fill="#ffffff" fill-opacity="0.95"/>
                <rect x="58" y="20" width="16" height="30" rx="4" fill="#ffffff"/>
                <rect x="62" y="14" width="8" height="6" rx="2" fill="#ccfbf1"/>
                <line x1="60" y1="34" x2="72" y2="34" stroke="#0d9488" stroke-width="2"/>
                <circle cx="30" cy="26" r="10" fill="#fbbf24"/>
                <path d="M30 10 L30 14 M30 38 L30 42 M14 26 L18 26 M42 26 L46 26" stroke="#fbbf24" stroke-width="2" stroke-linecap="round"/>
            </g>
        </svg>
    `,
    'corazones-calientes': `
        <svg viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="bg-cc" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#312e81"/>
                    <stop offset="50%" stop-color="#4f46e5"/>
                    <stop offset="100%" stop-color="#f97316"/>
                </linearGradient>
            </defs>
            <rect width="400" height="140" fill="url(#bg-cc)"/>
            <circle cx="50" cy="30" r="1.5" fill="#ffffff"/>
            <circle cx="90" cy="50" r="2" fill="#ffffff" opacity="0.8"/>
            <circle cx="310" cy="35" r="2" fill="#ffffff"/>
            <circle cx="360" cy="65" r="1.5" fill="#ffffff" opacity="0.7"/>
            <circle cx="280" cy="80" r="1.5" fill="#ffffff"/>
            <path d="M70 20 A10 10 0 0 0 76 34 A12 12 0 1 1 70 20 Z" fill="#fef08a"/>
            <g transform="translate(160, 22)">
                <circle cx="45" cy="50" r="32" fill="#f97316" fill-opacity="0.3"/>
                <path d="M18 36 C18 64 26 74 48 74 C70 74 78 64 78 36 Z" fill="#ffffff" fill-opacity="0.95"/>
                <path d="M38 18 Q42 10 46 18" stroke="#fde047" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                <path d="M50 16 Q54 8 58 16" stroke="#fde047" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                <path d="M48 45 C45 40 38 40 38 46 C38 52 48 58 48 58 C48 58 58 52 58 46 C58 40 51 40 48 45 Z" fill="#ef4444"/>
            </g>
        </svg>
    `
};

// ==========================================================================
// 2. DATOS DE PRUEBA (100% FICTICIOS)
// ==========================================================================

const DONAJUSTO_DATA = {
    indicadores: {
        totalPersonas: 790,
        comedoresActivos: 6,
        donacionesMes: 154,
        insumosCriticos: [
            { nombre: "Leche en polvo / entera", porcentajeUso: 92, categoria: "Lácteos", iconoType: "milk" },
            { nombre: "Harina 000 y Leudante", porcentajeUso: 84, categoria: "Secos", iconoType: "grain" },
            { nombre: "Arroz y Legumbres", porcentajeUso: 78, categoria: "Secos", iconoType: "grain" },
            { nombre: "Aceite de girasol", porcentajeUso: 70, categoria: "Aceites", iconoType: "oil" }
        ]
    },
    testimonios: [
        {
            nombre: "Doña Marta",
            rol: "Cocina Comunitaria — Rincón de Luz",
            cita: "Antes recibíamos 40 paquetes de fideos pero nos faltaba leche para los chicos. Con DonaJusto la gente dona justo lo que necesitamos cada semana.",
            iniciales: "DM",
            badge: "12 años en el barrio"
        },
        {
            nombre: "Graciela Benítez",
            rol: "Coordinadora — Sonrisas del Mañana",
            cita: "Saber que los vecinos pueden ver el stock en tiempo real nos dio una tranquilidad enorme. No se desperdicia nada y cada merienda está asegurada.",
            iniciales: "GB",
            badge: "110 niños cada tarde"
        },
        {
            nombre: "Esteban y Carlos",
            rol: "Voluntarios de Viandas — Corazones Calientes",
            cita: "En las noches frías, tener los insumos a tiempo para cocinar viandas calientes hace la diferencia entre acostarse con hambre o con el corazón lleno.",
            iniciales: "EC",
            badge: "Viandas nocturnas"
        }
    ],
    comedores: [
        {
            id: "rincon-de-luz",
            nombre: "Rincón de Luz",
            tipo: "Comedor Comunitario",
            barrio: "Barrio Esperanza Norte (Ficticio)",
            direccion: "Av. Las Acacias 450",
            coordinador: "Doña Marta (Cocina y merienda)",
            frase: "«Un plato de comida caliente es devolverle la dignidad al barrio»",
            personasAsistidas: 160,
            necesidadPrincipal: "Leche en polvo y azúcar",
            nivelUrgencia: "Alta",
            descripcion: "Brinda almuerzo diario y apoyo escolar a más de 40 familias del barrio en situación vulnerable.",
            horario: "Lunes a Viernes de 11:30 a 14:00",
            necesidades: [
                { item: "Leche en polvo", requerido: "30 kg", prioridad: "Urgente" },
                { item: "Azúcar común", requerido: "25 kg", prioridad: "Alta" },
                { item: "Cacao soluble", requerido: "15 kg", prioridad: "Media" }
            ],
            stock: [
                { item: "Fideos secos guiseros", actual: 45, maximo: 50, unidad: "kg" },
                { item: "Arroz blanco largo fino", actual: 30, maximo: 40, unidad: "kg" },
                { item: "Leche en polvo", actual: 3, maximo: 35, unidad: "kg" },
                { item: "Aceite de girasol", actual: 12, maximo: 20, unidad: "L" }
            ]
        },
        {
            id: "sonrisas-del-manana",
            nombre: "Sonrisas del Mañana",
            tipo: "Merendero Infantil",
            barrio: "Barrio Sol Naciente (Ficticio)",
            direccion: "Calle Los Ceibos 1220",
            coordinador: "Graciela Benítez (Coordinadora)",
            frase: "«Cada tarde nos esperan 110 caritas con ganas de merendar y aprender»",
            personasAsistidas: 110,
            necesidadPrincipal: "Harina leudante y cacao",
            nivelUrgencia: "Alta",
            descripcion: "Espacio de contención para meriendas, talleres recreativos y merienda reforzada para niños y niñas.",
            horario: "Lunes, Miércoles y Viernes de 16:30 a 18:30",
            necesidades: [
                { item: "Harina leudante", requerido: "40 kg", prioridad: "Urgente" },
                { item: "Cacao en polvo", requerido: "20 kg", prioridad: "Alta" },
                { item: "Galletitas dulces", requerido: "30 paquetes", prioridad: "Media" }
            ],
            stock: [
                { item: "Té y Mate Cocido", actual: 80, maximo: 100, unidad: "cajas" },
                { item: "Harina leudante", actual: 4, maximo: 45, unidad: "kg" },
                { item: "Azúcar", actual: 20, maximo: 30, unidad: "kg" },
                { item: "Leche larga vida", actual: 18, maximo: 60, unidad: "L" }
            ]
        },
        {
            id: "manos-unidas",
            nombre: "Manos Unidas",
            tipo: "Comedor y Merendero",
            barrio: "Villa Las Flores (Ficticio)",
            direccion: "Pasaje Primavera 89",
            coordinador: "Comité de 8 familias voluntarias",
            frase: "«Acá nadie come solo: compartimos lo que hay con amor y respeto»",
            personasAsistidas: 185,
            necesidadPrincipal: "Carne picada y verduras frescas",
            nivelUrgencia: "Media",
            descripcion: "Ofrece viandas nutricionales integrales para familias y personas mayores en soledad.",
            horario: "Martes, Jueves y Sábados de 12:00 a 14:30",
            necesidades: [
                { item: "Carne picada / pollo", requerido: "25 kg", prioridad: "Alta" },
                { item: "Papas y cebollas", requerido: "50 kg", prioridad: "Alta" },
                { item: "Puré de tomate", requerido: "40 unidades", prioridad: "Baja" }
            ],
            stock: [
                { item: "Puré de tomate", actual: 35, maximo: 40, unidad: "unid." },
                { item: "Lentejas secas", actual: 28, maximo: 30, unidad: "kg" },
                { item: "Verduras de estación", actual: 10, maximo: 60, unidad: "kg" },
                { item: "Fideos tallarines", actual: 40, maximo: 50, unidad: "kg" }
            ]
        },
        {
            id: "panza-llena",
            nombre: "Panza Llena Corazón Contento",
            tipo: "Comedor Comunitario",
            barrio: "Barrio San Jorge (Ficticio)",
            direccion: "Calle Moreno 2340",
            coordinador: "Carlos Morales (Huerta y cocina)",
            frase: "«De la huerta comunitaria directo a la mesa de nuestros vecinos»",
            personasAsistidas: 130,
            necesidadPrincipal: "Aceite comestible y condimentos",
            nivelUrgencia: "Media",
            descripcion: "Comedor vecinal autogestionado con cocina comunitaria y huerta agroecológica propia.",
            horario: "Lunes a Sábado de 12:00 a 13:30",
            necesidades: [
                { item: "Aceite de girasol", requerido: "20 L", prioridad: "Alta" },
                { item: "Sal gruesa y condimentos", requerido: "10 kg", prioridad: "Media" },
                { item: "Arroz", requerido: "25 kg", prioridad: "Baja" }
            ],
            stock: [
                { item: "Arroz", actual: 22, maximo: 30, unidad: "kg" },
                { item: "Harina común 000", actual: 35, maximo: 40, unidad: "kg" },
                { item: "Aceite", actual: 4, maximo: 25, unidad: "L" },
                { item: "Legumbres secas", actual: 18, maximo: 20, unidad: "kg" }
            ]
        },
        {
            id: "el-buen-sembrador",
            nombre: "El Buen Sembrador",
            tipo: "Merendero y Apoyo",
            barrio: "Barrio Los Aromos (Ficticio)",
            direccion: "Bv. Los Alerces 710",
            coordinador: "Silvia y equipo docente barrial",
            frase: "«Alimentamos el cuerpo y el futuro con apoyo escolar diario»",
            personasAsistidas: 95,
            necesidadPrincipal: "Leche líquida y mermeladas",
            nivelUrgencia: "Alta",
            descripcion: "Merendero barrial que brinda copa de leche, talleres de lectura y recreación.",
            horario: "Martes y Jueves de 17:00 a 19:00",
            necesidades: [
                { item: "Leche larga vida", requerido: "45 L", prioridad: "Urgente" },
                { item: "Mermelada / Dulces", requerido: "15 kg", prioridad: "Media" },
                { item: "Pan fresco / galletas", requerido: "20 kg", prioridad: "Alta" }
            ],
            stock: [
                { item: "Té en saquitos", actual: 50, maximo: 60, unidad: "cajas" },
                { item: "Azúcar", actual: 15, maximo: 20, unidad: "kg" },
                { item: "Leche larga vida", actual: 6, maximo: 50, unidad: "L" },
                { item: "Harina", actual: 20, maximo: 25, unidad: "kg" }
            ]
        },
        {
            id: "corazones-calientes",
            nombre: "Corazones Calientes",
            tipo: "Comedor Solidario",
            barrio: "Barrio Bella Vista Sur (Ficticio)",
            direccion: "Calle Ombú 55",
            coordinador: "Esteban y voluntarios de guardia",
            frase: "«En las noches más frías, salimos a abrigar el alma con viandas caseras»",
            personasAsistidas: 110,
            necesidadPrincipal: "Polenta, salsa de tomate y legumbres",
            nivelUrgencia: "Media",
            descripcion: "Iniciativa de vecinas que cocinan viandas calientes nocturnas para personas en situación de calle.",
            horario: "Miércoles y Domingos de 19:00 a 21:00",
            necesidades: [
                { item: "Polenta instantánea", requerido: "20 kg", prioridad: "Alta" },
                { item: "Salsa de tomate", requerido: "30 cajas", prioridad: "Media" },
                { item: "Lentejas y porotos", requerido: "15 kg", prioridad: "Media" }
            ],
            stock: [
                { item: "Fideos guiseros", actual: 30, maximo: 35, unidad: "kg" },
                { item: "Polenta", actual: 4, maximo: 25, unidad: "kg" },
                { item: "Arroz", actual: 25, maximo: 30, unidad: "kg" },
                { item: "Aceite", actual: 10, maximo: 15, unidad: "L" }
            ]
        }
    ]
};

let currentFilter = 'all';
let currentSearchTerm = '';


// ==========================================================================
// 3. CONTROLADOR DE LA APLICACIÓN (SPA)
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initMobileMenu();
    initNavigation();
    initCatalogFilters();
    renderImpactIndicators();
    renderTestimonials();
    renderCatalog();
    populateFormComedoresSelect();
    initModal();
    initForm();
    initSpotlightButton();
    animateCounters();
});

// ==========================================================================
// 4. MODO OSCURO / CLARO CON ICONOS SVG (EC-001)
// ==========================================================================

function initTheme() {
    const themeToggleBtn = document.getElementById('theme-toggle');
    const themeToggleMobileBtn = document.getElementById('theme-toggle-mobile');
    const themeIconContainer = document.getElementById('theme-icon-container');
    const themeIconContainerMobile = document.getElementById('theme-icon-container-mobile');
    
    const savedTheme = localStorage.getItem('donajusto-theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
        document.documentElement.classList.add('dark');
        updateThemeIcons(true);
    } else {
        document.documentElement.classList.remove('dark');
        updateThemeIcons(false);
    }

    function toggleTheme() {
        const isDark = document.documentElement.classList.toggle('dark');
        localStorage.setItem('donajusto-theme', isDark ? 'dark' : 'light');
        updateThemeIcons(isDark);
    }

    function updateThemeIcons(isDark) {
        const iconSvg = isDark ? SVG_ICONS.sun : SVG_ICONS.moon;
        if (themeIconContainer) themeIconContainer.innerHTML = iconSvg;
        if (themeIconContainerMobile) themeIconContainerMobile.innerHTML = iconSvg;
    }

    if (themeToggleBtn) themeToggleBtn.addEventListener('click', toggleTheme);
    if (themeToggleMobileBtn) themeToggleMobileBtn.addEventListener('click', toggleTheme);
}

// ==========================================================================
// 5. NAVEGACIÓN SPA & MENÚ MÓVIL (ADR-002, EC-007)
// ==========================================================================

function initMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    }
}

function initNavigation() {
    const navLinks = document.querySelectorAll('[data-target]');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('data-target');
            if (targetId) {
                navigateToView(targetId);
            }
        });
    });

    const brandLogo = document.getElementById('brand-logo');
    if (brandLogo) {
        brandLogo.addEventListener('click', (e) => {
            e.preventDefault();
            navigateToView('view-home');
        });
    }
}

function navigateToView(viewId) {
    const views = document.querySelectorAll('.view-section');
    views.forEach(view => {
        view.classList.add('hidden');
        view.classList.remove('fade-in');
    });

    const targetView = document.getElementById(viewId);
    if (targetView) {
        targetView.classList.remove('hidden');
        targetView.classList.add('fade-in');
        window.scrollTo({ top: 0, behavior: 'smooth' });

        if (viewId === 'view-home') {
            animateCounters();
        }
    }

    // EC-007: Cerrar menú móvil al navegar
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
        mobileMenu.classList.add('hidden');
    }

    // Actualizar estilos activos SOLAMENTE en los enlaces del navbar
    document.querySelectorAll('.nav-link').forEach(navLink => {
        if (navLink.getAttribute('data-target') === viewId) {
            navLink.classList.add('text-emerald-500', 'font-semibold');
        } else {
            navLink.classList.remove('text-emerald-500', 'font-semibold');
        }
    });
}

function initSpotlightButton() {
    const spotlightBtn = document.getElementById('hero-spotlight-btn');
    if (spotlightBtn) {
        spotlightBtn.addEventListener('click', () => {
            const select = document.getElementById('comedor-select');
            if (select) {
                select.value = 'rincon-de-luz';
            }
            navigateToView('view-form');
        });
    }
}

// ==========================================================================
// 6. INDICADORES DE IMPACTO & CONTADORES ANIMADOS
// ==========================================================================

function renderImpactIndicators() {
    const container = document.getElementById('impact-indicators');
    if (!container) return;

    const ind = DONAJUSTO_DATA.indicadores;

    container.innerHTML = `
        <!-- Métricas numéricas -->
        <div class="modern-card p-6 sm:p-8 rounded-3xl shadow-md flex flex-col justify-between border border-slate-200/80 dark:border-slate-800">
            <div>
                <div class="flex items-center justify-between mb-6">
                    <span class="text-xs uppercase tracking-wider font-bold text-slate-400">Resumen Comunitario</span>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-semibold border border-emerald-500/20">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        Datos en vivo
                    </span>
                </div>
                <div class="grid grid-cols-3 gap-3 sm:gap-4 text-center">
                    <div class="p-4 sm:p-5 bg-emerald-50/60 dark:bg-emerald-950/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/40">
                        <span class="text-2xl sm:text-4xl font-heading font-extrabold text-emerald-600 dark:text-emerald-400 counter-element" data-target="${ind.totalPersonas}">0</span>
                        <span class="block text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 mt-1 font-semibold">Vecinos asistidos</span>
                    </div>
                    <div class="p-4 sm:p-5 bg-teal-50/60 dark:bg-teal-950/20 rounded-2xl border border-teal-100 dark:border-teal-900/40">
                        <span class="text-2xl sm:text-4xl font-heading font-extrabold text-teal-600 dark:text-teal-400 counter-element" data-target="${ind.comedoresActivos}">0</span>
                        <span class="block text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 mt-1 font-semibold">Espacios en red</span>
                    </div>
                    <div class="p-4 sm:p-5 bg-amber-50/60 dark:bg-amber-950/20 rounded-2xl border border-amber-100 dark:border-amber-900/40">
                        <span class="text-2xl sm:text-4xl font-heading font-extrabold text-amber-600 dark:text-amber-400 counter-element" data-target="${ind.donacionesMes}">0</span>
                        <span class="block text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 mt-1 font-semibold">Aportes del mes</span>
                    </div>
                </div>
            </div>
            <div class="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                ${SVG_ICONS.location}
                <span>Distribución coordinada en comedores barriales de Río Cuarto.</span>
            </div>
        </div>

        <!-- Insumos más demandados -->
        <div class="modern-card p-6 sm:p-8 rounded-3xl shadow-md border border-slate-200/80 dark:border-slate-800">
            <div class="flex items-center justify-between mb-6">
                <span class="text-xs uppercase tracking-wider font-bold text-slate-400">Demanda Crítica de Insumos</span>
                <span class="text-xs font-semibold text-amber-700 dark:text-amber-300 bg-amber-500/15 border border-amber-500/25 px-3 py-1 rounded-full">Prioridad de entrega</span>
            </div>
            <div class="space-y-4">
                ${ind.insumosCriticos.map(item => {
                    let catIcon = SVG_ICONS.categoryGrain;
                    if (item.iconoType === 'milk') catIcon = SVG_ICONS.categoryMilk;
                    if (item.iconoType === 'oil') catIcon = SVG_ICONS.categoryOil;

                    const isHigh = item.porcentajeUso >= 85;

                    return `
                        <div>
                            <div class="flex justify-between items-center text-xs sm:text-sm font-semibold mb-1.5">
                                <span class="flex items-center gap-2 text-slate-800 dark:text-slate-100">
                                    <span>${catIcon}</span>
                                    <span>${item.nombre}</span>
                                    <span class="text-[10px] text-slate-400 font-normal">(${item.categoria})</span>
                                </span>
                                <span class="${isHigh ? 'text-red-500 font-bold' : 'text-amber-500 font-bold'}">${item.porcentajeUso}% demanda</span>
                            </div>
                            <progress value="${item.porcentajeUso}" max="100" class="h-2.5 ${isHigh ? 'critical' : ''}" aria-label="${item.nombre}"></progress>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

function animateCounters() {
    const counters = document.querySelectorAll('.counter-element');
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'), 10);
        let current = 0;
        const increment = Math.ceil(target / 25);
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                counter.textContent = target;
                clearInterval(timer);
            } else {
                counter.textContent = current;
            }
        }, 30);
    });
}

// ==========================================================================
// 7. CATÁLOGO: BÚSQUEDA Y FILTRADO EN TIEMPO REAL
// ==========================================================================

function initCatalogFilters() {
    const searchInput = document.getElementById('catalog-search');
    const filterChips = document.querySelectorAll('.filter-chip');

    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            currentSearchTerm = e.target.value.toLowerCase().trim();
            renderCatalog();
        });
    }

    filterChips.forEach(chip => {
        chip.addEventListener('click', () => {
            filterChips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            currentFilter = chip.getAttribute('data-filter');
            renderCatalog();
        });
    });
}

function getFilteredComedores() {
    return DONAJUSTO_DATA.comedores.filter(comedor => {
        let matchesFilter = true;
        if (currentFilter === 'urgente') {
            matchesFilter = (comedor.nivelUrgencia === 'Alta');
        } else if (currentFilter === 'Comedor') {
            matchesFilter = comedor.tipo.toLowerCase().includes('comedor');
        } else if (currentFilter === 'Merendero') {
            matchesFilter = comedor.tipo.toLowerCase().includes('merendero');
        }

        let matchesSearch = true;
        if (currentSearchTerm) {
            const inNombre = comedor.nombre.toLowerCase().includes(currentSearchTerm);
            const inBarrio = comedor.barrio.toLowerCase().includes(currentSearchTerm);
            const inNecesidad = comedor.necesidadPrincipal.toLowerCase().includes(currentSearchTerm);
            const inItems = comedor.necesidades.some(n => n.item.toLowerCase().includes(currentSearchTerm));
            matchesSearch = (inNombre || inBarrio || inNecesidad || inItems);
        }

        return matchesFilter && matchesSearch;
    });
}

function renderCatalog() {
    const grid = document.getElementById('catalog-grid');
    const countElement = document.getElementById('catalog-count');
    if (!grid) return;

    const filtered = getFilteredComedores();

    if (countElement) {
        countElement.textContent = `Mostrando ${filtered.length} de ${DONAJUSTO_DATA.comedores.length} comedores`;
    }

    if (filtered.length === 0) {
        grid.innerHTML = `
            <div class="col-span-full text-center py-16 px-4 modern-card rounded-3xl">
                <div class="w-16 h-16 mx-auto mb-4 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center">
                    ${SVG_ICONS.search}
                </div>
                <h4 class="font-heading text-lg font-bold mb-2">No se encontraron comedores</h4>
                <p class="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-6">
                    No hay resultados para "${currentSearchTerm || currentFilter}". Probá con otro término como "leche", "arroz" o limpiá el filtro.
                </p>
                <button id="btn-reset-filters" class="bg-emerald-500 hover:bg-emerald-600 force-text-white font-medium py-2.5 px-6 rounded-xl transition-colors text-sm min-h-[44px]">
                    Mostrar todos los comedores
                </button>
            </div>
        `;

        const resetBtn = document.getElementById('btn-reset-filters');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                currentSearchTerm = '';
                currentFilter = 'all';
                const searchInput = document.getElementById('catalog-search');
                if (searchInput) searchInput.value = '';
                document.querySelectorAll('.filter-chip').forEach(c => {
                    c.classList.toggle('active', c.getAttribute('data-filter') === 'all');
                });
                renderCatalog();
            });
        }
        return;
    }

    grid.innerHTML = filtered.map(comedor => {
        const isUrgent = comedor.nivelUrgencia === 'Alta';
        const badgeClass = isUrgent ? 'badge-urgent pulse-badge' : 'badge-medium';

        const urgencyIcon = isUrgent ? SVG_ICONS.alertRed : SVG_ICONS.alert;
        const bannerSvg = COMEDOR_BANNERS[comedor.id] || '';

        return `
            <article class="modern-card rounded-3xl overflow-hidden flex flex-col justify-between hover:border-emerald-500/50 shadow-md hover:shadow-xl transition-all duration-300 group">
                <!-- Banner Ilustrado Superior con Badges Flotantes -->
                <div class="illustration-banner">
                    ${bannerSvg}
                    <!-- Capa de gradiente y badges flotantes discretos -->
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/20 flex flex-col justify-between p-3 pointer-events-none">
                        <div class="flex justify-between items-center gap-2">
                            <span class="floating-banner-badge inline-flex items-center gap-1.5 font-bold px-2.5 py-1 rounded-full shadow-sm border ${badgeClass}">
                                ${urgencyIcon}
                                <span>Urgencia ${comedor.nivelUrgencia}</span>
                            </span>
                            <span class="floating-banner-badge badge-persons inline-flex items-center gap-1.5 font-semibold px-2.5 py-1 rounded-full shadow-sm border">
                                ${SVG_ICONS.users}
                                <span>${comedor.personasAsistidas} pers.</span>
                            </span>
                        </div>
                        <div class="text-white drop-shadow-sm flex justify-between items-center text-xs">
                            <span class="text-[11px] font-bold tracking-wide text-emerald-300 uppercase">${comedor.tipo}</span>
                            <span class="text-[11px] text-slate-200 flex items-center gap-1">${SVG_ICONS.clock} ${comedor.horario.split('de')[0].trim()}</span>
                        </div>
                    </div>
                </div>

                <div class="p-6 flex-grow flex flex-col justify-between space-y-4">
                    <div>
                        <!-- Título y Localización -->
                        <div class="mb-2">
                            <h3 class="font-heading text-xl font-bold tracking-tight mb-1 text-slate-900 dark:text-white group-hover:text-emerald-500 transition-colors">
                                ${comedor.nombre}
                            </h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-medium">
                                ${SVG_ICONS.location}
                                <span>${comedor.barrio}</span>
                            </p>
                        </div>

                        <!-- Coordinador / Rostro Humano -->
                        <div class="inline-flex items-center gap-2 text-[11px] text-emerald-700 dark:text-emerald-300 bg-emerald-500/10 dark:bg-emerald-500/15 px-3 py-1.5 rounded-xl font-semibold mb-2">
                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            <span>${comedor.coordinador}</span>
                        </div>

                        <!-- Frase Emotiva -->
                        <p class="text-xs text-slate-500 dark:text-slate-400 italic mb-3 font-normal leading-relaxed">
                            ${comedor.frase}
                        </p>
                        
                        <p class="text-xs text-slate-600 dark:text-slate-300 mb-4 line-clamp-2 leading-relaxed">
                            ${comedor.descripcion}
                        </p>

                        <!-- Necesidad Inmediata Destacada -->
                        <div class="bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-emerald-500/5 dark:from-emerald-500/15 dark:to-teal-500/15 p-3.5 rounded-2xl border border-emerald-500/25">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-300 block mb-1">
                                Necesidad inmediata prioritaria:
                            </span>
                            <span class="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                                ${SVG_ICONS.package}
                                <span>${comedor.necesidadPrincipal}</span>
                            </span>
                        </div>
                    </div>

                    <!-- Botón de Acción -->
                    <button 
                        class="btn-ver-detalle w-full bg-emerald-500 hover:bg-emerald-600 force-text-white font-semibold py-3 px-4 rounded-xl transition-all duration-150 min-h-[44px] shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2 group cursor-pointer"
                        data-comedor-id="${comedor.id}"
                        aria-label="Ver detalles y stock de ${comedor.nombre}">
                        <span>Ver detalles y stock</span>
                        <span class="inline-block transition-transform duration-150 group-hover:translate-x-1">${SVG_ICONS.arrowRight}</span>
                    </button>
                </div>
            </article>
        `;
    }).join('');

    document.querySelectorAll('.btn-ver-detalle').forEach(btn => {
        btn.addEventListener('click', () => {
            const comedorId = btn.getAttribute('data-comedor-id');
            openModal(comedorId);
        });
    });
}

function populateFormComedoresSelect() {
    const select = document.getElementById('comedor-select');
    if (!select) return;

    select.innerHTML = `<option value="">Seleccione un comedor o merendero...</option>` +
        DONAJUSTO_DATA.comedores.map(c => `
            <option value="${c.id}">${c.nombre} (${c.barrio})</option>
        `).join('');
}

// ==========================================================================
// 8. MODAL DE DETALLE (ADR-003, EC-006, EC-007)
// ==========================================================================

let activeModalComedorId = null;

function initModal() {
    const modal = document.getElementById('detail-modal');
    const modalOverlay = document.getElementById('modal-overlay');
    const modalCloseBtn = document.getElementById('modal-close');
    const modalActionBtn = document.getElementById('modal-action-btn');

    if (!modal) return;

    function closeModal() {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
        activeModalComedorId = null;
    }

    if (modalOverlay) modalOverlay.addEventListener('click', closeModal);
    if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);

    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
            closeModal();
        }
    });

    if (modalActionBtn) {
        modalActionBtn.addEventListener('click', () => {
            if (activeModalComedorId) {
                const select = document.getElementById('comedor-select');
                if (select) {
                    select.value = activeModalComedorId;
                }
            }
            closeModal();
            navigateToView('view-form');
        });
    }
}

function openModal(comedorId) {
    const comedor = DONAJUSTO_DATA.comedores.find(c => c.id === comedorId);
    if (!comedor) return;

    activeModalComedorId = comedorId;

    const modal = document.getElementById('detail-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalSubtitle = document.getElementById('modal-subtitle');
    const modalContent = document.getElementById('modal-content');

    modalTitle.textContent = comedor.nombre;
    if (modalSubtitle) {
        modalSubtitle.textContent = `${comedor.tipo} • ${comedor.barrio}`;
    }

    const bannerSvg = COMEDOR_BANNERS[comedor.id] || '';

    modalContent.innerHTML = `
        <div class="space-y-6">
            <!-- Banner Ilustrado del Espacio -->
            <div class="illustration-banner rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-700/60">
                ${bannerSvg}
            </div>

            <!-- Coordinador y Frase -->
            <div class="p-4 rounded-2xl bg-emerald-500/10 dark:bg-emerald-500/15 border border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2.5">
                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span class="text-xs font-bold text-emerald-800 dark:text-emerald-300">Responsable: ${comedor.coordinador}</span>
                </div>
                <span class="text-xs italic text-slate-600 dark:text-slate-300">${comedor.frase}</span>
            </div>

            <!-- Datos Generales -->
            <div class="bg-slate-50 dark:bg-slate-900/40 p-4 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs mb-3">
                    <p class="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                        ${SVG_ICONS.location} <span class="font-medium">${comedor.direccion}</span>
                    </p>
                    <p class="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                        ${SVG_ICONS.clock} <span>${comedor.horario}</span>
                    </p>
                    <p class="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                        ${SVG_ICONS.users} <span class="font-medium">Asiste a ${comedor.personasAsistidas} personas</span>
                    </p>
                    <p class="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                        ${comedor.nivelUrgencia === 'Alta' ? SVG_ICONS.alertRed : SVG_ICONS.alert}
                        <span class="font-medium">Prioridad: Urgencia ${comedor.nivelUrgencia}</span>
                    </p>
                </div>
                <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed border-t border-slate-200 dark:border-slate-800 pt-3">
                    ${comedor.descripcion}
                </p>
            </div>

            <!-- Necesidades Prioritarias -->
            <div class="bg-amber-50/80 dark:bg-amber-950/20 p-5 rounded-2xl border border-amber-200/80 dark:border-amber-800/80">
                <div class="flex items-center justify-between mb-3">
                    <h4 class="font-heading text-sm font-bold text-amber-900 dark:text-amber-200 flex items-center gap-2">
                        ${SVG_ICONS.alert}
                        <span>Insumos prioritarios solicitados</span>
                    </h4>
                    <span class="text-[10px] text-amber-700 dark:text-amber-300 font-semibold uppercase">Requerido hoy</span>
                </div>
                <ul class="space-y-2.5">
                    ${comedor.necesidades.map(n => `
                        <li class="flex justify-between items-center text-xs bg-white/80 dark:bg-slate-800/80 p-3 rounded-xl border border-amber-200/50 dark:border-amber-800/40">
                            <span class="font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                                <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                                <span>${n.item}</span>
                            </span>
                            <div class="flex items-center gap-2">
                                <span class="text-slate-500 dark:text-slate-400 font-medium">${n.requerido}</span>
                                <span class="px-2.5 py-0.5 rounded text-[10px] font-bold ${
                                    n.prioridad === 'Urgente' ? 'bg-red-500 text-white' : 'bg-amber-500 text-white'
                                }">${n.prioridad}</span>
                            </div>
                        </li>
                    `).join('')}
                </ul>
            </div>

            <!-- Estado de Stock con Barras <progress> sin estilos inline (EC-006) -->
            <div>
                <div class="flex items-center justify-between mb-4">
                    <h4 class="font-heading text-sm font-bold flex items-center gap-2">
                        ${SVG_ICONS.package}
                        <span>Nivel de stock actual en depósito</span>
                    </h4>
                    <span class="text-[11px] text-slate-400 font-normal">Capacidad operativa</span>
                </div>
                <div class="space-y-3.5">
                    ${comedor.stock.map(s => {
                        const porcentaje = Math.round((s.actual / s.maximo) * 100);
                        const isCritical = porcentaje < 25;
                        const alertaColor = isCritical ? 'text-red-500 font-bold' : 'text-slate-600 dark:text-slate-300';
                        return `
                            <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-100 dark:border-slate-800">
                                <div class="flex justify-between text-xs mb-1.5">
                                    <span class="font-semibold">${s.item}</span>
                                    <span class="${alertaColor}">
                                        ${s.actual} / ${s.maximo} ${s.unidad} (${porcentaje}%) ${isCritical ? '• Crítico' : ''}
                                    </span>
                                </div>
                                <progress value="${s.actual}" max="${s.maximo}" class="h-2.5 ${isCritical ? 'critical' : ''}" aria-label="${s.item}"></progress>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        </div>
    `;

    document.body.classList.add('overflow-hidden');
    modal.classList.remove('hidden');
}

// ==========================================================================
// 8.1 TESTIMONIOS Y VOCES DEL BARRIO
// ==========================================================================

function renderTestimonials() {
    const grid = document.getElementById('testimonials-grid');
    if (!grid || !DONAJUSTO_DATA.testimonios) return;

    grid.innerHTML = DONAJUSTO_DATA.testimonios.map((t, idx) => {
        const bgAvatars = ['bg-emerald-500', 'bg-amber-500', 'bg-teal-600'];
        const avatarBg = bgAvatars[idx % bgAvatars.length];

        return `
            <div class="modern-card p-6 sm:p-7 rounded-3xl shadow-sm testimonial-card flex flex-col justify-between border border-slate-200/80 dark:border-slate-800">
                <div>
                    <div class="flex justify-between items-center mb-4">
                        <span class="text-emerald-500 dark:text-emerald-400 opacity-70">
                            <svg class="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/></svg>
                        </span>
                        <span class="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">
                            ${t.badge}
                        </span>
                    </div>
                    <p class="text-xs sm:text-sm text-slate-700 dark:text-slate-200 italic leading-relaxed mb-6">
                        "${t.cita}"
                    </p>
                </div>
                <div class="flex items-center gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <div class="w-10 h-10 rounded-full ${avatarBg} force-text-white font-heading font-extrabold text-xs flex items-center justify-center flex-shrink-0 shadow-sm">
                        ${t.iniciales}
                    </div>
                    <div class="min-w-0">
                        <h4 class="font-heading font-bold text-sm text-slate-900 dark:text-white truncate">${t.nombre}</h4>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400 truncate">${t.rol}</p>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// ==========================================================================
// 9. FORMULARIO DE DONACIÓN Y NOTIFICACIÓN TOAST (DoD)
// ==========================================================================

function initForm() {
    const form = document.getElementById('donation-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const donorName = document.getElementById('donor-name').value.trim();
        const select = document.getElementById('comedor-select');
        const comedorNombre = select.options[select.selectedIndex]?.text || "el comedor seleccionado";

        if (!donorName) return;

        showToast(`¡Muchas gracias ${donorName}! Tu donación coordinada para ${comedorNombre} fue registrada.`);

        form.reset();
    });
}

function showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');

    if (!toast || !toastMessage) return;

    toastMessage.textContent = message;

    toast.classList.remove('translate-y-[150%]', 'opacity-0');
    toast.classList.add('translate-y-0', 'opacity-100');

    setTimeout(() => {
        toast.classList.remove('translate-y-0', 'opacity-100');
        toast.classList.add('translate-y-[150%]', 'opacity-0');
    }, 4000);
}
